package com.exer7ballonojosephine;

import android.app.*;
import android.os.*;

public class SecondActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);
    }

}
