package com.exer7ballonojosephine;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		Button btn=(Button)findViewById(R.id.mainButton);
		btn.setOnClickListener(new View. OnClickListener(){

				@Override
				public void onClick(View p1)
				{Intent in=new Intent(MainActivity.this, SecondActivity.class);
					startActivity(in);
					// TODO: Implement this method
				}
			});
    }
}
